(function($){
	$(function(){

        
        // Phone nav
        $('.hamburger').click(function () {
            $("body").toggleClass("navShown");
            $(".nav-wrap").fadeToggle()
        });
        
        // header top
        $('.header-close').click(function (e) {
            e.preventDefault()
            $('.header-top-section').hide();
        });
        
        // hero slider
        if($('.hero-thumb-item-wrap').length){
            $('.hero-thumb-item-wrap').slick({
                dots: false,
                arrows:true,
                autoplaySpeed:5000,
                infinite: true,
                navigation:false,
                speed: 300,
                slidesToShow:1,
                slidesToScroll: 1,
            });
        }
        
        // select
        if ($("select.selectric-select").length) {
            $("select.selectric-select").selectric({

            });
        }
        
        // even-odd slider
        $('.even-odd-content-slider').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            dots:false,
            fade: false,
            autoplay:true,
            autoplaySpeed: 4000,
            asNavFor: '.even-odd-slider-item-wrap'
        });
        $('.even-odd-slider-item-wrap').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            asNavFor: '.even-odd-content-slider',
            dots: false,
            arrows:true,
            autoplay:true,
            autoplaySpeed: 4000,
            fade:true,
            focusOnSelect: true
        });
        
        // blog page
        $(".hide-item").slice(0, 3).show();
        $(".hide-btn").on("click", function (e) {
            e.preventDefault();
            $(".hide-item:hidden").slice(0, 3).slideDown();
            if ($(".hide-item:hidden").length == 0) {
                $(".hide-btn").hide();
            }
        });
        
        
	})// End ready function.
   
    
})(jQuery)